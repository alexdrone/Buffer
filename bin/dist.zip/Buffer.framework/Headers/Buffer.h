#import <UIKit/UIKit.h>

//! Project version number for BufferDiff.
FOUNDATION_EXPORT double BufferDiffVersionNumber;

//! Project version string for BufferDiff.
FOUNDATION_EXPORT const unsigned char BufferDiffVersionString[];

// In this header, you should import all the public headers of your framework using modelments like #import <BufferDiff/PublicHeader.h>


